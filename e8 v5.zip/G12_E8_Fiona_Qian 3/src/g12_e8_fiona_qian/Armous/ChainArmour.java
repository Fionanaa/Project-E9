package g12_e8_fiona_qian.Armous;

import g12_e8_fiona_qian.Armour;

public class ChainArmour extends Armour{
    
    @Override
    public String toString() {
	return "ChainArmour  + " + level;
    }

    private int level = 0;
    public ChainArmour(int level) {
	this.setLevel(level);
	// TODO Auto-generated constructor stub
    }

    private int armor = 14;

    @Override
    public int getArmor() {
        return this.armor;

    }

    public int getLevel() {
	return level;
    }

    public void setLevel(int level) {
	this.level = level;
    }

}
