package g12_e8_fiona_qian.Armous;

import g12_e8_fiona_qian.Armour;

public class ClothArmour extends Armour {
    private int level = 0;
    private int armor = 10;

    public ClothArmour(int level) {
	this.level = level;
	// TODO Auto-generated constructor stub
    }



    @Override
    public int getArmor() {
        return this.armor;

    }

    public int getLevel() {
        return level;
    }



    public void setLevel(int level) {
        this.level = level;
    }



    @Override
    public String toString() {
        return " Cloth Armour +" + this.level;
    }

}
