package g12_e8_fiona_qian.Armous;

import g12_e8_fiona_qian.Armour;

public class LeatherArmour extends Armour {
    @Override
    public String toString() {
	return "LeatherArmour [level=" + level + ", armor=" + armor + "]";
    }

    private int level;
    public LeatherArmour(int level) {
	this.setLevel(level);

    }

    private int armor = 12;

    @Override
    public int getArmor() {
        return this.armor;

    }

    public int getLevel() {
	return level;
    }

    public void setLevel(int level) {
	this.level = level;
    }

}
