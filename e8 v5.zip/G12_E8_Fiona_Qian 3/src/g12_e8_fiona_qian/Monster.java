package g12_e8_fiona_qian;

import java.util.Random;

public class Monster extends PlayableCharacter {

    Random rng = new Random();

    public Monster(int level, int maxHp, int ac) {

        this.level = level;
        this.maxHp = maxHp;
        this.curHp = maxHp;
        this.armourClass = ac;
    }


    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getMaxHp() {
        return maxHp;
    }

    public void setMaxHp(int maxHp) {
        this.maxHp = maxHp;
    }

    public int getCurHp() {
        return curHp;
    }

    public void setCurHp(int curHp) {
        this.curHp = curHp;
    }

    public int getArmourClass() {
        return armourClass;
    }

    public void setArmourClass(int armourClass) {
        this.armourClass = armourClass;
    }

    @Override
    public String showClass() {

        return "Monster";
    }

    @Override
    public int getAttackRoll() {

        return rng.nextInt(6) + 1 + this.level;
    }

    //the damge value monster gets
    @Override
    public int getDamageRoll() {
        return rng.nextInt(6) + 1 + this.level;
    }

    //monster gets AC
    @Override
    public int getAC() {
        //System.out.println("Monster has: "+this.armourClass+" AC");
        return this.armourClass;
        
    }

}
