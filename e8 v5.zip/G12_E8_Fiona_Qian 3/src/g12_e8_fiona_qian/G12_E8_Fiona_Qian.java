package g12_e8_fiona_qian;

import java.util.Scanner;


public class G12_E8_Fiona_Qian {

    public static void main(String[] args) {
        int choice = 0;
        World world = new World();
        Scanner keyboard = new Scanner(System.in);

        do {
            System.out.println("~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("1. View Character");
            System.out.println("2. UseEquip Items");
            System.out.println("3. Shop for Items");
            System.out.println("4. Change hero class");
            System.out.println("5. Fight");
            choice = keyboard.nextInt();
            keyboard.nextLine();

            if (choice == 1) {
                System.out.println("~~~~~~~CHARACTER~~~~~~~~");
                world.viewCharacter();
            } else if (choice == 2) {
                System.out.println("~~~~~~~ITEMS~~~~~~~~");
                world.useEquip();
            } else if (choice == 3) {
                System.out.println("~~~~~~~SHOP~~~~~~~~");
                world.shop();
                
            }else if (choice == 4) {
                System.out.println("~~~~~~~CHANGE HERO CLASS~~~~~~~~");
                world.changeClass();
                
            } else if (choice == 5) {
                System.out.println("~~~~~~~FIGHT  + world.round + ~~~~~~~~");
                world.startBattle();
            } 
            
            if (world.round==6){
                System.out.println("Congrats! You Win!");
                choice = 0;
            }

        } while (choice != 0);
        

    }
    
}
