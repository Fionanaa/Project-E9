package g12_e8_fiona_qian;

import g12_e8_fiona_qian.Armous.ChainArmour;
import g12_e8_fiona_qian.Armous.LeatherArmour;
import g12_e8_fiona_qian.Armous.ClothArmour;
import g12_e8_fiona_qian.Potion.DexPotion;
import g12_e8_fiona_qian.Potion.HPPotion;
import g12_e8_fiona_qian.Potion.IntPotion;
import g12_e8_fiona_qian.Potion.StrPotion;

import java.util.Random;
import java.util.Scanner;

class World {
	int STR = 0;
    int curRound = 1;

    Random rng = new Random();
    //create an array of monsters
    Monster m1 = new Monster(1, 8, 10);
    Monster m2 = new Monster(1, 8 + (rng.nextInt(4) + 1), 11);
    Monster m3 = new Monster(2, 8 + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1), 11);
    Monster m4 = new Monster(2, 8 + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1), 12);
    Monster m5 = new Monster(3, 8 + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1), 13);

    Monster[] monsterTeam = {m1, m2, m3, m4, m5};

    Scanner keyboard = new Scanner(System.in);
    //create a new hero
    Hero player;
    int round;
    Monster monster;

    //constructor
    public World() {
        System.out.println("A World is Created!");
        this.player = new Hero();
    }

    //two players attck each other with two dif situations
    // getattackroll to tell if it's hit or miss
    public void attack(PlayableCharacter curPlayer, PlayableCharacter scarecrow) {
        System.out.println();
        System.out.println(curPlayer.getClass().getSimpleName() + " attacking " + scarecrow.getClass().getSimpleName());
        int heroAttack = curPlayer.getAttackRoll();
        int monsterAc = scarecrow.getAC();
        if(scarecrow instanceof Warrior) {
        	Warrior temp = new Warrior((Hero) scarecrow);
        	STR = temp.getSTR();
        	if(STR > 0) {
        	monsterAc -= STR;}
        }
        if(STR > 0 && scarecrow instanceof Warrior)
        { System.out.print("Warrior("+ monsterAc + "-"+ STR+")"+heroAttack + " Attack vs " + monsterAc + " AC");}
        System.out.print(heroAttack + " Attack vs " + monsterAc + " AC");
        if (heroAttack >= monsterAc) {
        	
            System.out.println(" = Hits!");
            int dmg = curPlayer.getDamageRoll();
            scarecrow.takeDamage(dmg);
        } else {
            System.out.println(" = Miss!");
        }

    }

    //attacker and defender continue to fight with each to each other until the HP of attacker is less or equal to 0
    public boolean fight(PlayableCharacter curPlayer, PlayableCharacter rawrA) {

        while (curPlayer.curHp > 0 && rawrA.curHp > 0) {
            attack(curPlayer, rawrA);
            if (rawrA.curHp > 0) {
                attack(rawrA, curPlayer);
            }
        }
        if (curPlayer.curHp < 0) {
            return false;

        } else {
            return true;
        }
    }

    void viewInventory() {
        for (int i = 0; i < this.player.Inventory.size(); i++) {
            System.out.print(i + 1);
            System.out.println("." + this.player.Inventory.get(i));
        }
    }

    void viewCharacter() {
        this.player.viewCharacter();
    }
//add or remove items from inventory array

    void useEquip() {
        viewInventory();
        System.out.println("Which item do you want to use/equip?");
        int index = keyboard.nextInt();
        while (index < 1 || index > this.player.Inventory.size()) {
            System.out.println("item not found");
            index = keyboard.nextInt();
        }
        Item item = this.player.Inventory.get(index - 1);
        System.out.println(this.player.Inventory.get(index - 1));
        if (item instanceof Equipment) {
            if (item instanceof Weapon) {
                this.player.Inventory.remove(index - 1);
                this.player.Inventory.add(this.player.weapon);
                this.player.weapon = (Weapon) item;
            } else {
                this.player.Inventory.remove(index - 1);
                this.player.Inventory.add(this.player.armour);
                this.player.armour = (Armour) item;
            }
        } else {
            this.player.Inventory.remove(index - 1);
            Consumable potion = (Consumable) item;
            potion.drink(this.player);
        }
    }
//ask for users to but items
    void shop() {
        System.out.println("What would you like to buy? You have $ " + player.getInitMoney());
        System.out.println("1. Sword");
        System.out.println("2. Cloth Armour");
        System.out.println("3. Leather Armour");
        System.out.println("4. Chain Armour");
        System.out.println("5. HP Potion");
        int chooseItem = keyboard.nextInt();
        keyboard.nextLine();
        while (chooseItem < 1 || chooseItem > 5) {
            System.out.println("Invalid input");
            chooseItem = keyboard.nextInt();
        }

        if (chooseItem == 1) {
            System.out.println("What level of the item would you like to buy (0-5)?");
            int chooseLevel = keyboard.nextInt();
            while (chooseLevel < 0 || chooseLevel > 5) {
                System.out.println("Invalid input");
                chooseLevel = keyboard.nextInt();
            }
            int cost = chooseLevel * 100;
            System.out.printf("Are you sure to buy Sword for %d $?(1. Yes 2. No)", cost);
            int chooseBoolean = keyboard.nextInt();
            while (chooseBoolean < 1 || chooseBoolean > 2) {
                System.out.println("Invalid input");
                chooseBoolean = keyboard.nextInt();
            }
            if (chooseBoolean == 2) {
                return;
            } else {
                if (this.player.getInitMoney() < cost) {
                    System.out.println("You don't have enough money to buy this!");
                } else {
                    int money = this.player.getInitMoney();
                    this.player.setInitMoney(money - cost);
                    Sword sword = new Sword(chooseLevel);
                    this.player.Inventory.add(sword);
                }
            }
        }

        if (chooseItem == 2) {
            System.out.println("What level of the item would you like to buy (0-5)?");
            int chooseLevel = keyboard.nextInt();
            while (chooseLevel < 0 || chooseLevel > 5) {
                System.out.println("Invalid input");
                chooseLevel = keyboard.nextInt();
            }
            int cost = chooseLevel * 100;
            System.out.printf("Are you sure to buy Cloth Armour for %d $?(1. Yes 2. No)", cost);
            int chooseBoolean = keyboard.nextInt();
            while (chooseBoolean < 1 || chooseBoolean > 2) {
                System.out.println("Invalid input");
                chooseBoolean = keyboard.nextInt();
            }
            if (chooseBoolean == 2) {
                return;
            } else {
                if (this.player.getInitMoney() < cost) {
                    System.out.println("You don't have enough money to buy this!");
                } else {
                    int money = this.player.getInitMoney();
                    this.player.setInitMoney(money - cost);
                    ClothArmour clotharmour = new ClothArmour(chooseLevel);
                    this.player.Inventory.add(clotharmour);
                }
            }
        }
        if (chooseItem == 3) {
            System.out.println("What level of the item would you like to buy (0-5)?");
            int chooseLevel = keyboard.nextInt();
            while (chooseLevel < 0 || chooseLevel > 5) {
                System.out.println("Invalid input");
                chooseLevel = keyboard.nextInt();
            }
            int cost = chooseLevel * 200 + 100;
            System.out.printf("Are you sure to buy Leather Armour for %d $?(1. Yes 2. No)", cost);
            int chooseBoolean = keyboard.nextInt();
            while (chooseBoolean < 1 || chooseBoolean > 2) {
                System.out.println("Invalid input");
                chooseBoolean = keyboard.nextInt();
            }
            if (chooseBoolean == 2) {
                return;
            } else {
                if (this.player.getInitMoney() < cost) {
                    System.out.println("You don't have enough money to buy this!");
                } else {
                    int money = this.player.getInitMoney();
                    this.player.setInitMoney(money - cost);
                    LeatherArmour leatherarmour = new LeatherArmour(chooseLevel);
                    this.player.Inventory.add(leatherarmour);
                }
            }
        }
        if (chooseItem == 4) {
            System.out.println("What level of the item would you like to buy (0-5)?");
            int chooseLevel = keyboard.nextInt();
            while (chooseLevel < 0 || chooseLevel > 5) {
                System.out.println("Invalid input");
                chooseLevel = keyboard.nextInt();
            }
            int cost = chooseLevel * 200 + 300;
            System.out.printf("Are you sure to buy Leather Armour for %d $?(1. Yes 2. No)", cost);
            int chooseBoolean = keyboard.nextInt();
            while (chooseBoolean < 1 || chooseBoolean > 2) {
                System.out.println("Invalid input");
                chooseBoolean = keyboard.nextInt();
            }
            if (chooseBoolean == 2) {
                return;
            } else {
                if (this.player.getInitMoney() < cost) {
                    System.out.println("You don't have enough money to buy this!");
                } else {
                    int money = this.player.getInitMoney();
                    this.player.setInitMoney(money - cost);
                    ChainArmour chainarmour = new ChainArmour(chooseLevel);
                    this.player.Inventory.add(chainarmour);
                }
            }
        }
        if (chooseItem == 5) {
            System.out.println("What level of the item would you like to buy (5-25)?");
            int chooseLevel = keyboard.nextInt();
            while (chooseLevel < 5 || chooseLevel > 25) {
                System.out.println("Invalid input");
                chooseLevel = keyboard.nextInt();
            }
            int cost = chooseLevel * 10;
            System.out.printf("Are you sure to buy HP Potion for %d $?(1. Yes 2. No)", cost);
            int chooseBoolean = keyboard.nextInt();
            while (chooseBoolean < 1 || chooseBoolean > 2) {
                System.out.println("Invalid input");
                chooseBoolean = keyboard.nextInt();
            }
            if (chooseBoolean == 2) {
                return;
            } else {
                if (this.player.getInitMoney() < cost) {
                    System.out.println("You don't have enough money to buy this!");
                } else {
                    int money = this.player.getInitMoney();
                    this.player.setInitMoney(money - cost);
                    HPPotion hppotion = new HPPotion(chooseLevel);
                    this.player.Inventory.add(hppotion);
                }
            }

        }

    }

//Hero fight with monsters for some rounds    
//to add  amount of gold , upgrade level, raise one of the Hero's three statistic and give random item when the Hero wins
    void startBattle() {

        Random rng = new Random();
        System.out.println("Round " + curRound);
        if (fight(this.player, this.monsterTeam[curRound - 1])) {
            System.out.println("Hero wins!");
            gainrandomitem();
            int ranmoney = rng.nextInt(curRound * 100 - 100 + 1) + 100;
            this.player.setInitMoney(this.player.getInitMoney() + ranmoney);
            System.out.println("Gained a $" + ranmoney + "!");
            this.player.setLevel(this.player.getLevel() + 1);
            System.out.println("Gained a Level (Lv." + this.player.getLevel() + ")!");
            System.out.println("What do you want to add a point to? (1.STR 2.DEX 3.INT)");
            int number = keyboard.nextInt();
            keyboard.nextLine();
            addPoint(number);

            //increase both curhp ang maxhp
            int ran = rng.nextInt(6) + 1;
            this.player.setMaxHp(this.player.getMaxHp() + ran);
            System.out.println("Gained " + ran + " Max HP!");
            if ((this.player.getCurHp() + ran) < this.player.getMaxHp()) {
                this.player.setCurHp(this.player.getCurHp() + ran);
            } else {
                this.player.setCurHp(this.player.getMaxHp());
            }
            curRound++;

        } else {
            curRound = 1;
            this.player = new Hero();
            m1 = new Monster(1, 8, 10);
            m2 = new Monster(1, 8 + (rng.nextInt(4) + 1), 11);
            m3 = new Monster(2, 8 + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1), 11);
            m4 = new Monster(2, 8 + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1), 12);
            m5 = new Monster(3, 8 + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1) + (rng.nextInt(4) + 1), 13);
            monsterTeam [0]=m1;        
            monsterTeam [1]=m2;
            monsterTeam [2]=m3;
            monsterTeam [3]=m4;
            monsterTeam [4]=m5;
                    
        }

    }


//hero get radom items
    private void gainrandomitem() {
        Random rng = new Random();
        int randomGetNumber = rng.nextInt(8);
        if (randomGetNumber == 0) {
            Sword sword = new Sword(curRound);
            System.out.println("Gained a sword!");
            this.player.Inventory.add(sword);
        } else if (randomGetNumber == 1) {
            int randomNumberAgain = rng.nextInt(3);
            if (randomNumberAgain == 0) {
                ClothArmour clotharmour = new ClothArmour(curRound);
                System.out.println("Gained a ClothArmour +1!");
                this.player.Inventory.add(clotharmour);
            }
            if (randomNumberAgain == 1) {
                LeatherArmour leatherarmour = new LeatherArmour(curRound);
                System.out.println("Gained a LeatherArmour +1!");
                this.player.Inventory.add(leatherarmour);
            }
            if (randomNumberAgain == 2) {
                ChainArmour chainarmour = new ChainArmour(curRound);
                System.out.println("Gained a ChainArmour +1!");
                this.player.Inventory.add(chainarmour);
            }

        } else if (randomGetNumber == 2 || randomGetNumber == 3 || randomGetNumber == 4) {
            int randomNumberb = rng.nextInt(3);
            if (randomNumberb == 0) {
                StrPotion a = new StrPotion(curRound);
                System.out.println("Gained a StrPotion+1!");
                this.player.Inventory.add(a);
            }
            if (randomNumberb == 1) {
                DexPotion b = new DexPotion(curRound);
                System.out.println("Gained a DexPotion+1!");
                this.player.Inventory.add(b);
            }
            if (randomNumberb == 2) {
                IntPotion c = new IntPotion(curRound);
                System.out.println("Gained a IntPotion+1!");
                this.player.Inventory.add(c);
            }
        } else if (randomGetNumber == 5 || randomGetNumber == 6 || randomGetNumber == 7) {
            HPPotion hppotion = new HPPotion(curRound);
            System.out.println("Gained a HPPotion +1 !");
            this.player.Inventory.add(hppotion);
        }

    }
//add a point to the stats

    private void addPoint(int number) {
        if (number == 1) {
            System.out.println("Gained 1 Str!");
            this.player.setSTR(this.player.getSTR() + 1);

        } else if (number == 2) {
            System.out.println("Gained 1 Dex!");
            this.player.setDEX(this.player.getDEX() + 1);

        } else if (number == 3) {
            System.out.println("Gained 1 Int!");
            this.player.setINT(this.player.getINT() + 1);

        }

    }

	public void changeClass() {
		
		System.out.print("select a class -- warrior");
		Hero w = new Warrior(this.player);
		this.player = w;
		
		// TODO Auto-generated method stub
		
	}

}
