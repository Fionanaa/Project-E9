package g12_e8_fiona_qian;

import g12_e8_fiona_qian.Equipment;

abstract public class Armour extends Equipment {

    abstract public int getArmor();

}
