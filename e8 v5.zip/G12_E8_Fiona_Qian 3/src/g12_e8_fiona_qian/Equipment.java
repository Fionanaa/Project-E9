package g12_e8_fiona_qian;

//abstract class
abstract class Equipment extends Item {

}
