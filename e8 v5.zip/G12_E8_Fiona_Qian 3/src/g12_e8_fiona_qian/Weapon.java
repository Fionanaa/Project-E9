package g12_e8_fiona_qian;

abstract class Weapon extends Equipment {//weapon is a abstract thing

    abstract public int getWeaponDamage();

}
