package g12_e8_fiona_qian;

public abstract class Consumable extends Item {
    public int level;
                
    public abstract void drink(Hero hero);
    
}
