package g12_e8_fiona_qian;

import java.util.Random;

public class Bow extends Weapon {


    private int level;
    Random rng = new Random();

    //constructor with level arguement
    public Bow(int level) {

        this.level = level;

    }

    @Override
    public String toString() {
        return "Bow +" + this.level;
    }

    //sword gets random damage from 1 to 6
    public int getWeaponDamage() {

    	 return rng.nextInt(6) + 1;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

}