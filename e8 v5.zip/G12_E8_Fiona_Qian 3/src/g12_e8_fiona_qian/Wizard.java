package g12_e8_fiona_qian;

public class Wizard extends Hero{


	public Wizard(Hero player) {
		this.curHp = player.curHp;
		this.maxHp = player.maxHp;
		this.Inventory = player.Inventory;
		this.setINT(player.getINT());
		this.setSTR(player.getSTR());
		this.setDEX(player.getDEX());
		this.weapon = player.weapon;
		this.armour = player.armour;
		this.level = player.level;
		this.setInitMoney(player.getInitMoney());
		// TODO Auto-generated constructor stub
	}
	
	
    public int getAttackRoll() {

        if (this.weapon instanceof Sword) {
            int base = rng.nextInt(20) + 1 ;
            Sword curWeapon = (Sword) this.weapon;
            int total = base +curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            int newTotal = total + this.getINT();
            System.out.println("(Wizard:" + total + "+" + this.getINT()+")");
            return newTotal;

        }
        if (this.weapon instanceof Bow) {
            int base = rng.nextInt(20) + 1 ;
            Bow curWeapon = (Bow) this.weapon;
            int total = base +curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            int newTotal = total + this.getINT();
            System.out.println("(Wizard:" + total + "+" + this.getINT()+")");
            return newTotal;

        }
        if (this.weapon instanceof Staff) {
            int base = rng.nextInt(20) + 1 ;
            Staff curWeapon = (Staff) this.weapon;
            int total = base +curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            int newTotal = total + this.getINT();
            System.out.println("(Wizard:" + total + "+" + this.getINT()+")");
            return newTotal;

        }
        if (this.weapon instanceof Axe) {
            int base = rng.nextInt(20) + 1 ;
            Axe curWeapon = (Axe) this.weapon;
            int total = base  +curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            int newTotal = total + this.getINT();
            System.out.println("(Wizard:" + total + "+" + this.getINT()+")");
            return newTotal;

        }else {
            int a = rng.nextInt(20) + 1;
            int total = a + this.level;
            System.out.println("Rolled " + a + " + " + this.level + "(Player Lvl) = Total: " + total);
            int newTotal = total + this.getINT();
            System.out.println("(Wizard:" + total + "+" + this.getINT()+")");
            return newTotal;

        }
        
        

    }

}

