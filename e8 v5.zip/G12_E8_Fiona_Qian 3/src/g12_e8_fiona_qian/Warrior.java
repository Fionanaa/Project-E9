package g12_e8_fiona_qian;



public class Warrior extends Hero{




	public Warrior(Hero player) {
		this.curHp = player.curHp;
		this.maxHp = player.maxHp;
		this.Inventory = player.Inventory;
		this.setINT(player.getINT());
		this.setSTR(player.getSTR());
		this.setDEX(player.getDEX());
		this.weapon = player.weapon;
		this.armour = player.armour;
		this.level = player.level;
		this.setInitMoney(player.getInitMoney());
		// TODO Auto-generated constructor stub
	}
	
	
    @Override
    public int getAttackRoll() {

        if (this.weapon instanceof Sword) {
            int base = rng.nextInt(20) + 1 ;
            Sword curWeapon = (Sword) this.weapon;
            int total = base + curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            if(this.getSTR()>0) 
            {
            int newTotal = total + this.getSTR();
            System.out.println("(Warrior:" + total + "+" + this.getSTR()+")");
            return newTotal;}
            else {
            System.out.println("(Warrior:" + total + ")");
            return total;}

        }
        if (this.weapon instanceof Bow) {
            int base = rng.nextInt(20) + 1 ;
            Bow curWeapon = (Bow) this.weapon;
            int total = base + curWeapon.getLevel() + this.level;
            
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            if(this.getSTR()>0) 
            {
            int newTotal = total + this.getSTR();
            System.out.println("(Warrior:" + total + "+" + this.getSTR()+")");
            return newTotal;}
            else {
            System.out.println("(Warrior:" + total + ")");
            return total;}


        }
        if (this.weapon instanceof Staff) {
            int base = rng.nextInt(20) + 1 ;
            Staff curWeapon = (Staff) this.weapon;
            int total = base  +curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            if(this.getSTR()>0) 
            {
            int newTotal = total + this.getSTR();
            System.out.println("(Warrior:" + total + "+" + this.getSTR()+")");
            return newTotal;}
            else {
            System.out.println("(Warrior:" + total + ")");
            return total;}


        }
        if (this.weapon instanceof Axe) {
            int base = rng.nextInt(20) + 1 ;
            Axe curWeapon = (Axe) this.weapon;
            int total = base  +curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            if(this.getSTR()>0) 
            {
            int newTotal = total + this.getSTR();
            System.out.println("(Warrior:" + total + "+" + this.getSTR()+")");
            return newTotal;}
            else {
            System.out.println("(Warrior:" + total + ")");
            return total;}

        }else {
            int a = rng.nextInt(20) + 1;
            int total = a + this.level;
            if(this.getSTR()>0) {
            System.out.println("Rolled " + a + " + " + this.level + "(Player Lvl) = Total: " + total);
            return total;}else {
            int newTotal = total + this.getSTR();
            System.out.println("(Warrior:" + total + "+" + this.getSTR()+")");
            return newTotal;}

        }

    }

}
