package g12_e8_fiona_qian;

import g12_e8_fiona_qian.Potion.HPPotion;
import g12_e8_fiona_qian.Armous.ClothArmour;
import java.util.ArrayList;
import java.util.Random;

public class Hero extends PlayableCharacter {
  
    Random rng = new Random();
    ArrayList<Item> shop = new ArrayList<Item>();
    
    ArrayList<Item> Inventory = new ArrayList<Item>();
  
    public int getSTR() {
        return STR;
    }

    public void setSTR(int sTR) {
        STR = sTR;
    }

    public int getDEX() {
        return DEX;
    }

    public void setDEX(int dEX) {
        DEX = dEX;
    }

    public int getINT() {
        return INT;
    }

    public void setINT(int iNT) {
        INT = iNT;
    }

    Weapon weapon;
    Armour armour;

    private int STR, DEX, INT, InitMoney;

    public Hero() {//constructor
        int[] array = {0, -1, 1};
        int STRIndex = rng.nextInt(3);
        int DEXIndex = rng.nextInt(3);
        int INTIndex = rng.nextInt(3);

        System.out.println("A Hero is Born!");
        this.level = 1;
        this.maxHp = rng.nextInt(7) + 6;
        //this.maxHp= 999;
        this.curHp = this.maxHp;
        this.armour = new ClothArmour(0);
        this.STR = array[STRIndex];
        this.INT = array[INTIndex];
        this.DEX = array[DEXIndex];
        this.setInitMoney(0);
        this.weapon = new Sword(0);

        HPPotion HpPotion = new HPPotion(5);
        Inventory.add(HpPotion);
    }

    //equip function tell if it is weapon or armour
    void equip(Equipment itemToEquip) {

        if (itemToEquip instanceof Weapon) {// if it's a weapon
            this.weapon = (Weapon) itemToEquip;
            System.out.println("Equipping  " + this.weapon);

        } else if (itemToEquip instanceof Armour) {
            this.armour = (Armour) itemToEquip;

        }

    }

    @Override
    public String toString() {
        return "Hero [rng=" + rng + ", Inventory=" + Inventory + ", weapon=" + weapon + ", armour=" + armour + ", STR="
                + STR + ", DEX=" + DEX + ", INT=" + INT + ", InitMoney=" + getInitMoney() + "]";
    }

    public void viewCharacter() {
        String curClass = showClass();
        System.out.println("Class: " + curClass + "\t" + "Total $: " + this.getInitMoney());
        System.out.println("HP:" + this.curHp + "/" + this.maxHp + "\t Lvl:" + this.level);
        System.out.println("STR:" + this.STR + "\t" + "DEX:" + this.DEX + "\t" + "INT:" + this.INT);
        if (this.weapon != null) {
            System.out.println("WEAPON: " + this.weapon);
        }
        System.out.println("ARMOUR:" + this.armour);
    }

    public void gainLevel() {
        this.level++;
        int givenHp = rng.nextInt(6) + 1;//1-6
        this.curHp += givenHp;
        this.maxHp += givenHp;
        System.out.printf("Gained a level (Lv.%d)!", this.level);
        System.out.println();
        System.out.printf("Gained %d Max HP!", givenHp);
        System.out.println();
    }

    @Override
    public String showClass() {
        return "Hero";
    }

    //attack value depending on lvl,weapon, and weapon lvl
    @Override
    public int getAttackRoll() {

        if (this.weapon instanceof Sword) {
            int base = rng.nextInt(20) + 1 ;
            Sword curWeapon = (Sword) this.weapon;
            int total = base + +curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);

            return total;

        }
        if (this.weapon instanceof Bow) {
            int base = rng.nextInt(20) + 1 ;
            Bow curWeapon = (Bow) this.weapon;
            int total = base + +curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            return total;

        }
        if (this.weapon instanceof Staff) {
            int base = rng.nextInt(20) + 1 ;
            Staff curWeapon = (Staff) this.weapon;
            int total = base + +curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            return total;

        }
        if (this.weapon instanceof Axe) {
            int base = rng.nextInt(20) + 1 ;
            Axe curWeapon = (Axe) this.weapon;
            int total = base + +curWeapon.getLevel() + this.level;
            
            System.out.println("Rolled " + base + " + " + this.level + "(Player Lvl) + " + curWeapon.getLevel() + "(Weapon Lvl) + = Total: " + total);
            return total;

        }else {
            int a = rng.nextInt(20) + 1;
            int total = a + this.level;
            System.out.println("Rolled " + a + " + " + this.level + "(Player Lvl) = Total: " + total);
            return total;

        }

    }



    //rewrite for a new condition
    @Override
    public int getDamageRoll() {
        Random rng = new Random();
        int a;

        if (this.weapon == null) {
            a = rng.nextInt(4) + 1;

            System.out.println("Hero uses their bare fists for " + a + " damage");
            return a;  //1-4

        } else {
            int damage=weapon.getWeaponDamage();
            System.out.println("Hero uses their " + this.weapon + " for " + damage + " damage");
            return damage;
        }

    }

    @Override
    public int getAC() {

        return 0;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getCurHp() {
        return curHp;
    }

    public void setCurHp(int curHp) {
        this.curHp = curHp;
    }

    public int getMaxHp() {
        return maxHp;
    }

    public void setMaxHp(int maxHp) {
        this.maxHp = maxHp;
    }

    public int getInitMoney() {
        return InitMoney;
    }

    public void setInitMoney(int initMoney) {
        InitMoney = initMoney;
    }
    
    
}
