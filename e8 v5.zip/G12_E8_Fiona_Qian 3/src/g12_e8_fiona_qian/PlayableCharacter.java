package g12_e8_fiona_qian;

abstract class PlayableCharacter {

    public int level, curHp, maxHp, armourClass;

    public PlayableCharacter() {
        this.level = 1;
    }

    //overide in Hero and Monster
    public void takeDamage(int damage) {
	String name = this.getClass().getSimpleName();
        this.curHp -= damage;
        System.out.println(name +" takes " + damage + " damage (" + this.curHp + "/" + maxHp + "HP)");

    }

    //take damage not abstract
    abstract public String showClass();

    abstract public int getAttackRoll();

    abstract public int getDamageRoll();

    abstract public int getAC();//not the same way hero:cloth    monster:they just have it

}
