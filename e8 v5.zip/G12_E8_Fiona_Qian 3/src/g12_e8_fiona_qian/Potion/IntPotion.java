package g12_e8_fiona_qian.Potion;

import g12_e8_fiona_qian.Consumable;
import g12_e8_fiona_qian.Hero;

public class IntPotion extends Consumable{

    public IntPotion(int level) {
	this.level = level;
    }

    @Override
    public String toString() {
	return "INTPotion (+" + level + ")";
    }
    @Override
    public void drink(Hero hero) {
	int curINT= hero.getINT();
	hero.setINT(curINT+this.level);
	// TODO Auto-generated method stub
	
    }
}
