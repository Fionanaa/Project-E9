package g12_e8_fiona_qian.Potion;

import g12_e8_fiona_qian.Consumable;
import g12_e8_fiona_qian.Hero;

public class StrPotion extends Consumable{

    public StrPotion(int level) {
	this.level = level;
    }

    @Override
    public String toString() {
	return "STRPotion (+" + level + ")";
    }
    @Override
    public void drink(Hero hero) {
	int curSTR= hero.getSTR();
	hero.setSTR(curSTR+this.level);
	// TODO Auto-generated method stub
	
    }
}
