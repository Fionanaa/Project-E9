package g12_e8_fiona_qian.Potion;

import g12_e8_fiona_qian.Consumable;
import g12_e8_fiona_qian.Hero;

public class HPPotion extends Consumable{

    public HPPotion(int level) {
	this.level = level;
    }

    @Override
    public String toString() {
	return "HP Potion (+" + level + ")";
    }

    @Override
    public void drink(Hero hero) {
	int curHP= hero.getCurHp();
	
	if((curHP+this.level)>hero.getMaxHp()) {
	    hero.setCurHp(hero.getMaxHp());
	}else {
	    hero.setCurHp(curHP+this.level);
	    
	}
	
	// TODO Auto-generated method stub
	
    }
}
