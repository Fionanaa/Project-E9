package g12_e8_fiona_qian;

import java.util.Random;

public class Staff extends Weapon {

    private int level;
    Random rng = new Random();

    //constructor with level arguement
    public Staff(int level) {

        this.level = level;

    }

    @Override
    public String toString() {
        return "Staff +" + this.level;
    }

    //sword gets random damage from 1 to 6
    public int getWeaponDamage() {

    	 return rng.nextInt(4) + 1 ;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

}